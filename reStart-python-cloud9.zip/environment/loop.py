for x in range (0, 500):
    print(x)